package loader;

public abstract class TrashCanAb
{
	public abstract void Insert(int garbage);
	public abstract void Empty();
	public abstract String ToString();
}