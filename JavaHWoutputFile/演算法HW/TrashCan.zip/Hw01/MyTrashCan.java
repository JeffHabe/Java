package Hw01;

import loader.TrashCanAb;

public class MyTrashCan extends TrashCanAb {
	String trashCan = "";
	private int num = 0;

	public static void main(String[] args) {
	}

	@Override
	public void Insert(int garbage) {
		if (num == 0) {
			trashCan = Integer.toString(garbage);
			num = 1;
		} else {
			trashCan = garbage + "," + trashCan;
		}

	}

	@Override
	public void Empty() {
		trashCan = "";
		num = 0;
	}

	@Override
	public String ToString() {
		String str = "";
		str = "[" + trashCan + "]";
		return str;
	}

}
