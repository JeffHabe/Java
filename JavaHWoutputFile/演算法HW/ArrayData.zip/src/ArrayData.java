
import java.util.Random;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author User
 */
public final class ArrayData {

    double Test_Array[] = new double[5];

    public ArrayData() {
        this.Test_Array = Test_Array;
        setArray();
    }

    public ArrayData(double[] Test_Array) {
        this.Test_Array = Test_Array;
        double ans;
        max();
//        avg(A);
//        reverse(A);
//        shuffle(A);
//        toString(A);
//        inner_product(double[] B
//    );
    }

    public void setArray() {
//        throw new UnsupportedOperationException("Not supported yet.");
        Scanner scr = new Scanner(System.in);
        for (int i = 0; i < Test_Array.length; i++) {
            Test_Array[i] = scr.nextDouble();
        }//To change body of generated methods, choose Tools | Templates.
    }

    public double max() {

        double temp = Test_Array[0];
        for (int i = 0; i < Test_Array.length; i++) {
            if (temp < Test_Array[i]) {
                temp = Test_Array[i];
            }
        }
        double ary_Max = temp;
        return ary_Max;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayData A = new ArrayData();
        double Ans;
        Ans=A.max();
        System.out.println(Ans);
//        Scanner scr = new Scanner(System.in);
//        for (int i = 0; i < Test_Array.length; i++) {
//            Test_Array[i] = scr.nextDouble();
//        }
    }

}
